import React, { useState } from 'react';

function App() {
  const [jsonData, setJsonData] = useState('');
  const [responseData, setResponseData] = useState(null);
  const [error, setError] = useState('');
  const [selectedFilters, setSelectedFilters] = useState([]);

  // Function to handle JSON input and submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const parsedData = JSON.parse(jsonData); // Parse the inputted JSON
      const response = await fetch('http://localhost:3000/bfhl', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parsedData),
      });
      const result = await response.json();
  
      console.log('Full Backend Response:', result); // Log the entire response to console
  
      setResponseData(result); // Store the response in state
      setError(''); // Clear any errors
    } catch (err) {
      setError('Invalid JSON input');
      setResponseData(null);
    }
  };
  

  // Function to handle dropdown selection changes
  const handleFilterChange = (e) => {
    const { value, checked } = e.target;
    if (checked) {
      setSelectedFilters([...selectedFilters, value]);
    } else {
      setSelectedFilters(selectedFilters.filter((item) => item !== value));
    }
  };

  // Function to apply filters to the response data
  const getFilteredData = () => {
    if (!responseData) return null;
    let filteredData = {};
    
    if (selectedFilters.includes('Alphabets')) {
      filteredData.alphabets = responseData.alphabets;
    }
    if (selectedFilters.includes('Numbers')) {
      filteredData.numbers = responseData.numbers;
    }
    if (selectedFilters.includes('Highest Lowercase Alphabet')) {
      filteredData.highest_lowercase_alphabet = responseData.highest_lowercase_alphabet;
    }

    return filteredData;
  };

  // Rendering the form and response data
  return (
    <div>
      <h1>BFHL Frontend</h1>
      <form onSubmit={handleSubmit}>
        <textarea
          value={jsonData}
          onChange={(e) => setJsonData(e.target.value)}
          placeholder="Enter JSON data"
          rows={10}
          cols={50}
        />
        <br />
        <button type="submit">Submit</button>
      </form>
      
      {error && <p style={{ color: 'red' }}>{error}</p>}

      {responseData && (
        <div>
          <h3>Choose Filters:</h3>
          <label>
            <input
              type="checkbox"
              value="Alphabets"
              onChange={handleFilterChange}
            />
            Alphabets
          </label>
          <br />
          <label>
            <input
              type="checkbox"
              value="Numbers"
              onChange={handleFilterChange}
            />
            Numbers
          </label>
          <br />
          <label>
            <input
              type="checkbox"
              value="Highest Lowercase Alphabet"
              onChange={handleFilterChange}
            />
            Highest Lowercase Alphabet
          </label>
          
          {/* Display the filtered data */}
          <div>
            <h3>Filtered Response Data:</h3>
            <pre>{JSON.stringify(getFilteredData(), null, 2)}</pre>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
